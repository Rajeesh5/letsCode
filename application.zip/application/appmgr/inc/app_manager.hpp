#ifndef COM_BOSCH_COMMON_ITRAMS_APP_MANAGER_H_
#define COM_BOSCH_COMMON_ITRAMS_APP_MANAGER_H_

#include <csignal>
#include <dlfcn.h>
#include <utility>
#include <thread>
#include <mutex>
#include <functional>
#include <map>
#include <vector>
#include <iostream>

#include "plugin_interface.hpp"

namespace com::bosch::itrams_gen2e {
namespace appmgr {    

extern std::function<void(int)> sig_handler_closure;
extern void sigHandler(int signal);

class AppManager final{
 public:

    static AppManager* getInstance() {
        if (instance_ == nullptr) {
            instance_.reset(new AppManager());
        }        
        return instance_.get();
    }
    void start();
    void attachSignalHandler();
    std::shared_ptr<common::PluginInterface> registerPlugin(const std::string &plugin_path);
    void hookup();    

 private:

    AppManager() = default;
    ~AppManager() = default;

    AppManager(const AppManager&) = delete;
    AppManager & operator = (const AppManager &) = delete;    

    AppManager(const AppManager&&) = delete;
    AppManager & operator = (const AppManager &&) = delete;
    
    static std::function<void(AppManager*)>      deleter_;
    static std::unique_ptr<AppManager, 
            decltype(AppManager::deleter_)>      instance_;     
    static std::mutex                            mutex_;
    std::map<const std::string, void*>           handles_;

    void removeAllPlugins();
    common::PluginInterface* loadPlugin(const std::string& so_path);
};
}   // namespace appmgr
}   // namespace com::bosch::itrams_gen2e
#endif  // COM_BOSCH_COMMON_ITRAMS_APP_MANAGER_H_
