#include <iostream>
#include <thread>
#include <cstdlib> 
#include <typeinfo>

#include "app_manager.hpp"
#include "plugin_interface.hpp"
#include "data_types.hpp"
#include "event_handler.hpp"
#include "event_admin.hpp"


using namespace com::bosch::itrams_gen2e;

int main() {
    
  

    appmgr::AppManager *app_manager = appmgr::AppManager::getInstance();
    app_manager->attachSignalHandler();

    // app_manager->start();

    app_manager->hookup();   
 
  return 0;
}

