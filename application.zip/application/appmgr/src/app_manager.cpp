#include "app_manager.hpp"


namespace com::bosch::itrams_gen2e {
namespace appmgr {

std::function<void(int)> sig_handler_closure = nullptr;

void sigHandler(int signal) {
    if (sig_handler_closure) {
        sig_handler_closure(signal);
    }
}

std::function<void(AppManager*)> AppManager::deleter_ = [](AppManager* ptr) {    
    std::cout << "App-Manager teardown in progress.." << std::endl;
    ptr->removeAllPlugins(); 
    delete ptr; 
    std::cout << "App-manager Distroyed." << std::endl;
};

std::unique_ptr<AppManager, decltype(AppManager::deleter_)> AppManager::instance_(nullptr, AppManager::deleter_);
std::mutex AppManager::mutex_;

void AppManager::attachSignalHandler() {    

    // Creating lembda to have function that 
    // handles specific below signals :

    sig_handler_closure = [&](int signal) {
        switch (signal) {
        case SIGINT:
        case SIGTERM:
        case SIGSEGV:
        case SIGILL:
        case SIGFPE:
        case SIGHUP:
            /* fall through */
            // Clean-up !!! dont worry taken care by deleter
            exit(0);
        default:
            break;
        }
    };

    std::signal(SIGTERM, appmgr::sigHandler);   // Ctrl+C
    std::signal(SIGINT,  appmgr::sigHandler);   // Termination signal
    std::signal(SIGSEGV, appmgr::sigHandler);   // Segmentation fault
    std::signal(SIGILL,  appmgr::sigHandler);   // Illegal instruction fault
    std::signal(SIGFPE,  appmgr::sigHandler);   // Floating point exception
    std::signal(SIGHUP,  appmgr::sigHandler);   // Hang-up 
}  

std::shared_ptr<common::PluginInterface> AppManager::registerPlugin(const std::string &plugin_path) {
    common::PluginInterface* plugin = nullptr;
    plugin = loadPlugin(plugin_path);

    if (plugin != nullptr) {
        if (!plugin->init()) {
            std::cout << "Failed to initialize the \'" + plugin_path + "\' plugin" << std::endl;
            ::exit(1);
        }
        std::cout << "Shared library " + plugin_path + "loaded" << std::endl;
    } else { 
        std::cout<< "The shared library \'" + plugin_path + "\' could not be loaded" << std::endl;
    }

    // Wrap raw pointer with shared_ptr.
    return std::shared_ptr<common::PluginInterface>(plugin);
}

common::PluginInterface* AppManager::loadPlugin(const std::string& so_path) {

    common::PluginInterface* loaded_plugin = nullptr;
    void* plugin = ::dlopen(so_path.c_str(), RTLD_LAZY);
    if (plugin) {
        void* fn = ::dlsym(plugin, "Create");
        if (fn) {
            auto plugin_factory = reinterpret_cast<common::PluginInterface::CreateFn*>(fn);
            loaded_plugin = plugin_factory();

            handles_[so_path] = plugin;
        } else {
            std::cerr << "Unable to get Plugin CreateFn : " << ::dlerror() << std::endl;    
        }
    }
    else {
        std::cerr << "Error opening shared library: " << ::dlerror() << std::endl;
    }
    return loaded_plugin;
}

void AppManager::removeAllPlugins() {
    
    // Call the Plugin destructor to clean-up memeory before 
    // unload the plugin. It should be resposibility of Plugin developer
    // to write clean-up. If there is no clean-up create default destructor.
 
    for (auto& plugin : handles_) {
        void* handle = plugin.second;
        
        // Unload the plugin using dlclose
        if (handle) {
            if (::dlclose(handle) != 0) {
                std::cerr << "Error unloading shared library: " << ::dlerror() << std::endl;
            }
            else { 
                std::cout << "Library unloded :" << plugin.first << std::endl; 
            }
        }
    }
    // Clear the plugins map
    handles_.clear(); 
}

void AppManager::hookup() {
    while (true) {        
        std::this_thread::sleep_for(std::chrono::seconds(10));
    }
}
}   // namespace appmgr
}   // namespace com::bosch::itrams_gen2e
