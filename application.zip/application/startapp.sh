#!/bin/bash

# Start the itrams_gen2e application
./build/bin/itrams_gen2e &

# Check if the application started successfully
if [ $? -eq 0 ]; then
    echo "itrams_gen2e started successfully."
else
    echo "Failed to start itrams_gen2e."
fi
