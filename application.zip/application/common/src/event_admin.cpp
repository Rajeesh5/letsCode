#include <algorithm>
#include "event_admin.hpp"


namespace com::bosch::itrams_gen2e {
namespace common {

std::shared_ptr<EventAdmin> EventAdmin::instance_;
std::once_flag EventAdmin::initFlag_; 

EventAdmin::EventAdmin():is_async_thread_active(false) {};

void EventAdmin::postEvent(std::shared_ptr<Event> event) {
    {
        std::lock_guard<std::mutex> lock(async_event_mutex_);
        async_event_q_.push(event);
    }    
    if (!is_async_thread_active.exchange(true, std::memory_order_relaxed)) {

        std::thread t(&EventAdmin::processAsyncEvent, this);
        t.detach();  // Detach the thread to allow it to run independently
    }
}

void EventAdmin::registerService(std::vector<std::string> topics,
                                 std::shared_ptr<EventHandler> handler) {
    if (handler) {
        for (const auto& topic : topics) {
            handlers_[topic].push_back(handler);
        }
    }
}

void EventAdmin::processAsyncEvent() {
	std::shared_ptr<Event> event = nullptr;
    bool isQueueEmpty = false;
    do {
        std::unique_lock<std::mutex> locker(async_event_mutex_);
        if (!async_event_q_.empty()) {
            event = async_event_q_.front();
            async_event_q_.pop();
        } else {
            isQueueEmpty = true;
        }
        locker.unlock();

        if (!isQueueEmpty) {
            std::string topic = event->getTopic();
            if (handlers_.find(topic) != handlers_.end()) {
                for (auto eventHandler : handlers_[topic]) {
                    eventHandler->handleEvent(event);
                }
            }
        }
        locker.lock();
        isQueueEmpty = async_event_q_.empty();
        locker.unlock();
    } while (!isQueueEmpty);
	is_async_thread_active.store(false, std::memory_order_relaxed);
}
}   // namespace common
}   // namespace com::bosch::itrams_gen2e
