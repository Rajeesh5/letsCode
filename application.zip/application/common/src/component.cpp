 #include "component.hpp"
 
namespace com::bosch::itrams_gen2e {
namespace common {

std::shared_ptr<Component> Component::instance_;
std::once_flag Component::initFlag_;
 
void Component::registerPlugin(const std::string& cl_name, std::shared_ptr<PluginInterface> plugin) {

    if (cl_name.empty()) {
        throw std::invalid_argument("Plugin name is empty");
    }
    if (!plugin) {
        throw std::invalid_argument("Plugin is null for " + cl_name);
    }
    // Add into Map.
    plugins_[cl_name] = plugin;    
}

}   // common 
}   // com::bosch::itrams_gen2e