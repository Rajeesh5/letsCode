
#include "event_constants.hpp"


namespace com::bosch::itrams_gen2e {
namespace common {

// Note: Please follow the below naming convention of topic format- 
//       com/bosch/itrams/<module>/<event_nm>

const std::string EventConstants::TEST_EVENT_TOPIC = "com/bosch/itrams/test/event1";
const std::string EventConstants::TEST_COMMON_EVENT_TOPIC = "com/bosch/itrams/test/event2";
const std::string EventConstants::TEST_TELEPHONY_EVENT_TOPIC =  "com/bosch/itrams/test/event3";
const std::string EventConstants::TEST_MODEMGR_EVENT_TOPIC = "com/bosch/itrams/test/event4";
//Other Topics

} 
};
