#include "event.hpp"

namespace com::bosch::itrams_gen2e {
namespace common {

Event::Event(const std::string& topic):topic_(topic) { 
    validateTopicName(topic);
}

Event::Event(const std::string& topic, 
    const std::map<std::string, std::shared_ptr<void>>&&  properties):
    topic_(topic), properties_(std::move(properties)) {
    validateTopicName(topic);
}

void Event::validateTopicName(const std::string& topic) const {
    const char* chars = topic.c_str();
    int length = topic.length();
    if (length == 0) {
        throw std::invalid_argument("empty topic");
    }
    for (int i = 0; i < length; i++) {
        char ch = chars[i];
        if (ch == '/') {
            // Can't start or end with a '/' but anywhere else is okay
            if (i == 0 || (i == length - 1)) {
                throw std::invalid_argument("invalid topic: " + topic);
            }
            // Can't have "//" as that implies empty token
            if (chars[i - 1] == '/') {
                throw std::invalid_argument("invalid topic: " + topic);
            }
            continue;
        }
        if (('A' <= ch) && (ch <= 'Z')) {
            continue;
        }
        if (('a' <= ch) && (ch <= 'z')) {
            continue;
        }
        if (('0' <= ch) && (ch <= '9')) {
            continue;
        }
        if ((ch == '_') || (ch == '-')) {
            continue;
        }
        throw std::invalid_argument("invalid topic: " + topic);
    }
}

// Checks if a property with the given topic exists
bool Event::containsProperty(const std::string& topic) const {
    return properties_.find(topic) != properties_.end();
}

// Gets a vector of all property names
std::vector<std::string> Event::getPropertyNames() const {
    std::vector<std::string> result;
    result.reserve(properties_.size());
    for (const auto& entry : properties_) {
        result.push_back(entry.first);
    }
    return result;
}


const std::string Event::toString() const {
        return "[topic=" + topic_ + "]";
    }

const std::string Event::getTopic() const {
    return topic_;
}

std::size_t Event::hash() const {
    std::size_t seed = 0;

    // Combine the hash of the topic string
    hash_combine(seed, std::hash<std::string>{}(topic_));
    // Combine the hash of each property
    for (const auto& pair : properties_) {
        hash_combine(seed, std::hash<std::string>{}(pair.first));
        hash_combine(seed, std::hash<void*>{}(pair.second.get()));
    }
    return seed;
}

void Event::hash_combine(std::size_t& seed, std::size_t hash_value) const {
        seed ^= hash_value + 0x9e3779b9 + (seed << 6) + (seed >> 2);
}

}  // namespace common
}  // namespace com::bosch::itrams_gen2e