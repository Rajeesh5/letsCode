#include "data_types.hpp"

// Add your auto-generated header files here.

namespace com::bosch::itrams_gen2e {
namespace common {

// Add Event property key here :

const std::string PropertyKeys::TEST_KEY = "testing_key";

// Add Plugin name here :

const std::string PluginName::TEST_SHARED_PLUGIN = "SharedPlugin";


}  // namespace common
}  // namespace com::bosch::itrams_gen2e
