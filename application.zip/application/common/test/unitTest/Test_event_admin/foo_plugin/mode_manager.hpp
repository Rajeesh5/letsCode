#include "event_handler.hpp"
#include "event.hpp"

namespace com::bosch::itrams_gen2e {
namespace test_plugins {

class ModeManager : public common::EventHandler {
public:
	ModeManager();
	void handleEvent(std::shared_ptr<common::Event> event) override;
	int getModeManagerMsgCount();
	int getCommonMsgCount();
 private:	
	int commonMsgCount_;
	int modemanagerMsgCount_;
};
}
}