
#ifndef FOO_PLUGIN_H
#define FOO_PLUGIN_H

#include <thread>
#include <fstream>
#include <atomic>

#include "plugin_interface.hpp"
#include "mode_manager.hpp"
#include "shared_plugin.hpp"
#include "bar_plugin.hpp"
#include "component.hpp"


namespace com::bosch::itrams_gen2e {
namespace test_plugins {   

class FooPlugin : public common::PluginInterface {
public:  

    bool init() override;
    void activate() override; 
    int getModeManagerMsgCount() { return modemgr_->getModeManagerMsgCount(); }
	int getCommonMsgCount() { return modemgr_->getCommonMsgCount(); }

    void writeToFile(const std::string& threadName, const std::string& message);

    ~FooPlugin() override; 
private:    
    std::shared_ptr<SharedPlugin> sharedPlugin_;
    std::shared_ptr<ModeManager>  modemgr_;
    std::thread fooThread_;
    std::atomic<bool>  is_thread_active{false};
};
}   // namespace com::bosch::itrams_gen2e {
}   // plugins
#endif  // FOO_PLUGIN_H