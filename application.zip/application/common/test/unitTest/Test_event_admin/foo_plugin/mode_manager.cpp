#include "mode_manager.hpp"

namespace com::bosch::itrams_gen2e {
namespace test_plugins {


ModeManager::ModeManager():commonMsgCount_(0),modemanagerMsgCount_(0){ }

int ModeManager::getModeManagerMsgCount() { return  modemanagerMsgCount_; }

int ModeManager::getCommonMsgCount() { return commonMsgCount_; }

void ModeManager::handleEvent(std::shared_ptr<common::Event> event) {
	
	const std::string topic = event->getTopic();
	if(topic == common::EventConstants::TEST_COMMON_EVENT_TOPIC) {
		commonMsgCount_++;
	}
	else if(topic == common::EventConstants::TEST_MODEMGR_EVENT_TOPIC) {
		modemanagerMsgCount_++;
	}
	else {
		//Invalid Topic
	}
	
	// auto msg = *event->getProperty<std::string>(common::PropertyKeys::TEST_KEY);
	// std::cout << topic << " :: ModeManagerHandler Processing " << msg << std:: endl;	
}
}
}