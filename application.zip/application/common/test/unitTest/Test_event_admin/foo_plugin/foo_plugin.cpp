#include "foo_plugin.hpp"
#include "event_admin.hpp"

namespace com::bosch::itrams_gen2e {
namespace test_plugins {

ITRAMS_GEN2E_PLUGIN(FooPlugin);

FooPlugin::~FooPlugin() {
    std::cout<< "Distructor of FooPlugin Called" << std::endl;

    // Make Thread joinable
    is_thread_active.store(false);

    if(fooThread_.joinable()) {
      fooThread_.join();
    }

}

void FooPlugin::writeToFile(const std::string& threadName, const std::string& message) {

    std::ofstream outputFile("foo_file.txt", std::ios::app);  // Open file in append mode
    if (outputFile.is_open()) {
      while(is_thread_active.load()) {
        auto now = std::chrono::system_clock::now();
        std::time_t currentTime = std::chrono::system_clock::to_time_t(now);
        std::string timestamp = std::ctime(&currentTime);

        outputFile << "[" << timestamp.substr(0, timestamp.length() - 1) << "] ";
        outputFile << "[" << threadName << "] " << message << std::endl;

        std::this_thread::sleep_for(std::chrono::seconds(1));
      }
        outputFile.close();
    } else {
        std::cerr << "Error opening the file." << std::endl;
    }
}


bool FooPlugin::init() { 
    bool ret = true; 
    // return false if intialization not happen properly.
    std::shared_ptr<common::EventAdmin> admin = common::EventAdmin::getInstance();
        
    // Registering handlers
    modemgr_ = std::make_shared<ModeManager>();
    admin->registerService(
        { common::EventConstants::TEST_COMMON_EVENT_TOPIC,
          common::EventConstants::TEST_MODEMGR_EVENT_TOPIC
        }, modemgr_);

    std::shared_ptr<common::Component> component = common::Component::getInstance();
    sharedPlugin_= component->getPlugin<SharedPlugin>(common::PluginName::TEST_SHARED_PLUGIN);
    
    if(sharedPlugin_ == nullptr) {
      ret = false;
    }   


    fooThread_ = std::thread([this]() { 
      is_thread_active.store(true, std::memory_order_relaxed);
      writeToFile("FooThread", "Test-msg from foo") ;
    }); 

    return ret;
}

void FooPlugin::activate() {

    std::shared_ptr<common::EventAdmin> admin = common::EventAdmin::getInstance();    
    sharedPlugin_->sayHello();  

    int count =10;

    while(count > 0) {
	  auto event1 = std::make_shared<common::Event>(common::EventConstants::TEST_MODEMGR_EVENT_TOPIC);

    
      event1->addProperty(common::PropertyKeys::TEST_KEY, std::make_shared<std::string>("mode_mgr_payload"));
      admin->postEvent(event1);

      auto event2 = std::make_shared<common::Event>(common::EventConstants::TEST_TELEPHONY_EVENT_TOPIC);
      event2->addProperty(common::PropertyKeys::TEST_KEY, std::make_shared<std::string>("telephony_payload"));
      admin->postEvent(event2);
      
      auto event3 = std::make_shared<common::Event>(common::EventConstants::TEST_COMMON_EVENT_TOPIC);
      event3->addProperty(common::PropertyKeys::TEST_KEY, std::make_shared<std::string>("common_payload"));
      admin->postEvent(event3);
      count --;
    }
}
}   // com::bosch::itrams_gen2e
}   // plugins
