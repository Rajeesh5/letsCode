
#include "shared_plugin.hpp"

namespace com::bosch::itrams_gen2e {
namespace test_plugins {

ITRAMS_GEN2E_PLUGIN(SharedPlugin);

bool SharedPlugin::init() { 
    return true;
}

void SharedPlugin::activate() {

}

}   // com::bosch::itrams_gen2e
}   // test_plugins
