
#ifndef SHARED_PLUGIN_H
#define SHARED_PLUGIN_H

#include <iostream>
#include "plugin_interface.hpp"

namespace com::bosch::itrams_gen2e {
namespace test_plugins {   

class SharedPlugin : public common::PluginInterface {
public:  

    bool init() override;
    void activate() override;
    void sayHello() { std::cout << "Hello from Shared Plugin" << std::endl;} 

    // Note:: Here dafault destructor is enough for cleanup.
    ~SharedPlugin() override = default; 
};
}   // namespace com::bosch::itrams_gen2e {
}   // plugins
#endif  // SHARED_PLUGIN_H