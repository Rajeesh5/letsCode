
#include "event_handler.hpp"

namespace com::bosch::itrams_gen2e {
namespace test_plugins {

class Telephoney : public common::EventHandler {
 public:
	Telephoney();
	void handleEvent(std::shared_ptr<common::Event> event) override;
	int getTelephonyMsgCount();
	int getCommonMsgCount();

 private:	
	int commonMsgCount_;
	int telephonyMsgCount_;
};
}
}