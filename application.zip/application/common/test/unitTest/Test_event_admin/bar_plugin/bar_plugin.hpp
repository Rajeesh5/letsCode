#ifndef BAR_PLUGIN_H
#define BAR_PLUGIN_H

#include <thread>

#include "plugin_interface.hpp"
#include "telephoney.hpp"
#include "shared_plugin.hpp"
#include "component.hpp"

namespace com::bosch::itrams_gen2e {
namespace test_plugins {    

class BarPlugin : public common::PluginInterface {
public:
    bool init() override;
    void activate() override;
	int getTelephonyMsgCount() { return telephony_->getTelephonyMsgCount(); }
	int getCommonMsgCount() { return telephony_->getCommonMsgCount(); }
    ~BarPlugin() override;
    
    void writeToFile(const std::string& threadName, const std::string& message);
private:
    std::shared_ptr<SharedPlugin> sharedPlugin_;
    std::shared_ptr<Telephoney> telephony_;
    std::thread barThread_;    
};

}  // com::bosch::itrams_gen2e 
}  // test_plugins
#endif  // BAR_PLUGIN_H
