
#include <thread>
#include <fstream>
#include "bar_plugin.hpp"
#include "event_admin.hpp"

using namespace com::bosch::itrams_gen2e::common;

namespace com::bosch::itrams_gen2e {
namespace test_plugins {  

ITRAMS_GEN2E_PLUGIN(BarPlugin);

BarPlugin::~BarPlugin() {
    std::cout<< "Distructor of BarPlugin Called" << std::endl;

    // Nothing need to delete here.
    // Note : Detached thread dont wait for joining.
}

void BarPlugin::writeToFile(const std::string& threadName, const std::string& message) {

    std::ofstream outputFile("bar_file.txt", std::ios::app);  // Open file in append mode
    if (outputFile.is_open()) {
      while(true) {
        auto now = std::chrono::system_clock::now();
        std::time_t currentTime = std::chrono::system_clock::to_time_t(now);
        std::string timestamp = std::ctime(&currentTime);

        outputFile << "[" << timestamp.substr(0, timestamp.length() - 1) << "] ";
        outputFile << "[" << threadName << "] " << message << std::endl;

        std::this_thread::sleep_for(std::chrono::seconds(1));
      }
        outputFile.close();
    } else {
        std::cerr << "Error opening the file." << std::endl;
    }
}

bool BarPlugin::init() { 

    bool ret = true;  
    std::shared_ptr<common::EventAdmin> admin = common::EventAdmin::getInstance();
        
    telephony_ = std::make_shared<Telephoney>(); 
        // Registering handlers
    admin->registerService(
        { common::EventConstants::TEST_COMMON_EVENT_TOPIC,
          common::EventConstants::TEST_TELEPHONY_EVENT_TOPIC
        }, telephony_);

    std::shared_ptr<common::Component> component = common::Component::getInstance();
    sharedPlugin_ = component->getPlugin<SharedPlugin>(common::PluginName::TEST_SHARED_PLUGIN);

    if(sharedPlugin_ == nullptr) {
      ret = false;
    }      

    barThread_ = std::thread([this]() { 
      writeToFile("BarThread", "Test-msg from bar") ;
    });

    barThread_.detach();

    // However its a good pratice to make thread joinable.
  
    return ret;
}

void BarPlugin::activate() {

    sharedPlugin_->sayHello();
    std::shared_ptr<common::EventAdmin> admin = common::EventAdmin::getInstance();
    
    int count = 10;
    while(count > 0) {

	    auto event1 = std::make_shared<common::Event>(common::EventConstants::TEST_MODEMGR_EVENT_TOPIC);
      event1->addProperty(common::PropertyKeys::TEST_KEY, std::make_shared<std::string>("mode_mgr_payload"));
      admin->postEvent(event1);

      auto event2 = std::make_shared<common::Event>(common::EventConstants::TEST_TELEPHONY_EVENT_TOPIC);
      event2->addProperty(common::PropertyKeys::TEST_KEY, std::make_shared<std::string>("telephony_payload"));
      admin->postEvent(event2);
      
      auto event3 = std::make_shared<common::Event>(common::EventConstants::TEST_COMMON_EVENT_TOPIC);
      event3->addProperty(common::PropertyKeys::TEST_KEY, std::make_shared<std::string>("common_payload"));
      admin->postEvent(event3);
      count --;
    }
}

}  // namepsace com::bosch::itrams_gen2e 
}  // namespace test_plugins