#include "telephoney.hpp"

namespace com::bosch::itrams_gen2e {
namespace test_plugins {

	Telephoney::Telephoney():commonMsgCount_(0),telephonyMsgCount_(0){}

	int Telephoney::getTelephonyMsgCount() { return telephonyMsgCount_;}
	int Telephoney::getCommonMsgCount() { return commonMsgCount_;}

	void Telephoney::handleEvent(std::shared_ptr<common::Event> event) {
		const std::string topic = event->getTopic();

		if(topic == common::EventConstants::TEST_COMMON_EVENT_TOPIC) {
			commonMsgCount_++;
		}
		else if(topic == common::EventConstants::TEST_TELEPHONY_EVENT_TOPIC) {
			telephonyMsgCount_++;
		}
		else {
			//Invalid Topic
		}

		// Print out the recived-message
		// auto msg = *event->getProperty<std::string>(common::PropertyKeys::TEST_KEY);
		// std::cout <<  topic << " :: TelephoneyHandler Processing " << msg << std:: endl;		
		
	}
}
}