#include <gtest/gtest.h>
#include <thread>


#include "bar_plugin.hpp"
#include "foo_plugin.hpp"
#include "shared_plugin.hpp"
#include "component.hpp"
#include "app_manager.hpp"


using namespace com::bosch::itrams_gen2e;

class TestEvent : public ::testing::Test {
    virtual void SetUp() {
      std::cout << "SetUp\n";
    }
    virtual void TearDown() {
      std::cout <<"Teardown\n";
    }
};

// Google Test Case
TEST_F(TestEvent, TEST_EVENT_ADMIN) {

    std::shared_ptr<common::Component> component = common::Component::getInstance();
    appmgr::AppManager *app_manager = appmgr::AppManager::getInstance();

    app_manager->attachSignalHandler();

    // Note:: You cant be able to delete the app_manager instance
    // It is proteted from accidental delete.
    // delete app_manager;

    std::shared_ptr<common::PluginInterface> splugin = app_manager->registerPlugin("lib/libshared.so");

    component->registerPlugin(common::PluginName::TEST_SHARED_PLUGIN, splugin); 

    std::shared_ptr<common::PluginInterface> fplugin = app_manager->registerPlugin("lib/libfoo.so");
    std::shared_ptr<common::PluginInterface> bplugin = app_manager->registerPlugin("lib/libbar.so");

    std::thread ([&]{
      bplugin->activate();
    }).detach();

    std::thread ([&]{
      fplugin->activate();
    }).detach();

    std::this_thread::sleep_for(std::chrono::seconds(1));

    if (fplugin) {
      ASSERT_EQ(20, std::dynamic_pointer_cast<test_plugins::FooPlugin>(fplugin)->getModeManagerMsgCount());
      ASSERT_EQ(20 , std::dynamic_pointer_cast<test_plugins::FooPlugin>(fplugin)->getCommonMsgCount() );
    }

    if (bplugin) {
      ASSERT_EQ(20 , std::dynamic_pointer_cast<test_plugins::BarPlugin>(bplugin)->getTelephonyMsgCount() );
      ASSERT_EQ(20 , std::dynamic_pointer_cast<test_plugins::BarPlugin>(bplugin)->getCommonMsgCount() );   
    }    
}

TEST_F(TestEvent, TEST_COMPONENT) {

std::shared_ptr<common::Component> component = common::Component::getInstance();

/*
    test_plugins::SharedPlugin splugin ;
    
    component->registerPlugin(common::PluginName::TEST_SHARED_PLUGIN, 
                              std::make_shared<test_plugins::SharedPlugin>(&splugin)); 

    test_plugins::FooPlugin fplugin ;
    test_plugins::BarPlugin bplugin ;

    fplugin.init();
    bplugin.init();

    component->registerPlugin("FooPlugin", 
                              std::make_shared<test_plugins::FooPlugin>(&fplugin));
    
    component->registerPlugin("BarPlugin", 
                              std::make_shared<test_plugins::BarPlugin>(&bplugin));
*/
}