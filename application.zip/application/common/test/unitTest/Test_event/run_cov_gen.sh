#!/bin/bash
    BUILD_DIR="build"
# Check if the build directory exists

    if [ -d "$BUILD_DIR" ]; then
        echo "Build directory already exists. Removing"
        rm -rf "$BUILD_DIR"
    fi
# If not, create the build directory
    mkdir "$BUILD_DIR"
    echo "Build directory created."

# Change to the build directory
    cd "$BUILD_DIR"

# Run CMake
    cmake ..    
    make
#Run unit test 
    ./event_UT
#Generate lcov info files
    lcov --directory . --capture --output-file coverage.info
#Generate HTML report
    genhtml coverage.info --output-directory coverage_report
# End of script
