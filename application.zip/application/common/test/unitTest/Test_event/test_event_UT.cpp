#include <gtest/gtest.h>
#include <map>
#include "data_types.hpp"
#include "event.hpp"
#include "event_constants.hpp"


using namespace com::bosch::itrams_gen2e;

class Person {
public:
    Person(int age, const std::string&& name) : age_(age), name_(std::move(name)) {}
    int getAge() { return age_; };
    const std::string getName() const{ return name_; }
private:
    std::string name_;
    int age_;
};

enum class Priority {
    CRITICAL = 1,
    HIGH = 2,
    MEDIUM = 3,
    MINOR = 4,
    LOW = 5,
    DEFAULT = 6
};


class TestEvent : public ::testing::Test {

    virtual void SetUp() {
      std::cout << "SetUp\n";
    }

    virtual void TearDown() {
      std::cout <<"Teardown\n";
    }
};


// Google Test Case
TEST_F(TestEvent, TEST_OBJ_MAP) {
    
    std::map<std::string, std::shared_ptr<void> > propertiesMap =
    {
        {"Int",      std::make_shared<int>(42)},              // Example with int*
        {"Double",   std::make_shared<double>(3.14)},         // Example with double*
        {"Person",   std::make_shared<Person>(30, "MrX.")},   // Example with Person
    };
    
    common::Event event(common::EventConstants::TEST_EVENT_TOPIC, std::move(propertiesMap));

    event.addProperty<char>("Char", std::make_shared<char>('c'));
    event.addProperty<std::string>("Day", std::make_shared<std::string>("Sunday!!"));
    
    event.addProperty("Priority", std::make_shared <Priority>(Priority::CRITICAL));
    
     // set the stream of data buffer into properties_map
    std::vector<char> byteArrayValue = {'a', 'b', 'c', 'd'};
    std::vector<int> intArrayValue = {1, 2, 3, 4}; 
    
    event.addArrayProperty("CharArray", byteArrayValue.data(), byteArrayValue.size());       
    event.addArrayProperty("IntArray", intArrayValue.data(), intArrayValue.size());


    // Get all property names count
    std::vector<std::string> propertyNames = event.getPropertyNames();
    ASSERT_EQ(8 , propertyNames.size() );

    // Get properties value
    ASSERT_EQ('c', *event.getProperty<char>("Char"));
    ASSERT_EQ(3.14, *event.getProperty<double>("Double"));
    ASSERT_EQ(42,   *event.getProperty<int>("Int"));
    ASSERT_EQ("Sunday!!", *event.getProperty<std::string>("Day"));
    ASSERT_EQ("MrX.", event.getProperty<Person>("Person")->getName());

    const std::vector<char>* retrievedArray = event.getArrayProperty<char>("CharArray");
    if (retrievedArray) {
       ASSERT_EQ(4, retrievedArray->size());
    }
}

TEST_F(TestEvent, TEST_EVENT_EXCEPTION) {
    std::string topic = "invaid_topic_1234";
    try {        
        common::Event event(topic);
    }
    catch (const std::invalid_argument& e){
        ASSERT_EQ("invalid topic: " + topic , e.what());
    }
}

