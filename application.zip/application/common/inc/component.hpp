#ifndef COM_BOSCH_COMMON_ITRAMS_COMPONENT_H_
#define COM_BOSCH_COMMON_ITRAMS_COMPONENT_H_

#include <map>
#include <memory>
#include <mutex>
#include "plugin_interface.hpp"

namespace com::bosch::itrams_gen2e {
namespace common { 

class Component final {
public:
    static std::shared_ptr<Component> getInstance() {
        // Use std::call_once for thread safety initialization
        std::call_once(initFlag_, [&]() {
             instance_.reset(new Component());
        });
        return instance_;
    }
    
    template <typename T>
    std::shared_ptr<T> getPlugin(const std::string& cl_name) const {
        auto it = plugins_.find(cl_name);
        if (it != plugins_.end()) {
            auto castedPtr = std::dynamic_pointer_cast<T>(it->second);
            return castedPtr;
        }
        return nullptr;
    }

    void registerPlugin(const std::string& cl_name, std::shared_ptr<common::PluginInterface> plugin);

private:
    static std::shared_ptr<Component> instance_;
    static std::once_flag initFlag_;

    std::map<std::string, std::shared_ptr<common::PluginInterface>> plugins_;

    Component() = default;

    Component(const Component&) = delete;
    Component& operator=(const Component&) = delete;

    Component(Component&&) = delete;
    Component& operator=(const Component&&) = delete;
};
}   // common 
}   // com::bosch::itrams_gen2e

#endif  // COM_BOSCH_COMMON_ITRAMS_COMPONENT_H_
