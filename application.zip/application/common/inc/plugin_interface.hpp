#ifndef COM_BOSCH_COMMON_ITRAMS_PLUGIN_H_
#define COM_BOSCH_COMMON_ITRAMS_PLUGIN_H_

#include<string>

namespace com::bosch::itrams_gen2e {
namespace common {


#define ITRAMS_GEN2E_PLUGIN(T)                                    \
    extern "C" common::PluginInterface* Create() {                \
        return reinterpret_cast<common::PluginInterface*>(new T); \
    }

class PluginInterface {
 public:
    typedef PluginInterface* CreateFn();
    
    virtual ~PluginInterface() = default;

    /**
     * \brief Entry point of plugin
     *
     *  Once Plugin get created properly, App-Manager will trigger 
     *  activate API of releted plugin.
     */    
    virtual void activate() = 0;

    /**
     * \brief Initialize the plugin
     *
     * The return value is checked by the AppManager
     * to verify that the plugin has been correctly created.
     */
    virtual bool init() = 0;

    /**
     * \brief Return the version of the plugin interface used
     */
    std::string getVersion() const {
        return "1.0";
    }
};

}  // namespace common
}  // namespace com::bosch::itrams_gen2e
#endif  // COM_BOSCH_COMMON_ITRAMS_PLUGIN_H_

