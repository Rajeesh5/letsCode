#ifndef COM_BOSCH_COMMON_ITRAMS_EVENTHANDLER_H_
#define COM_BOSCH_COMMON_ITRAMS_EVENTHANDLER_H_

#include "data_types.hpp"
#include "event.hpp"

namespace com::bosch::itrams_gen2e {
namespace common { 

class EventHandler {
 public:
    virtual void handleEvent(std::shared_ptr<Event> event) = 0;
};

}  // namespace common
}  // namespace com::bosch::itrams_gen2e
#endif /* COM_BOSCH_COMMON_ITRAMS_EVENTHANDLER_H_ */   
