#ifndef COM_BOSCH_COMMON_ITRAMS_EVENTCONSTANTS_HPP_
#define COM_BOSCH_COMMON_ITRAMS_EVENTCONSTANTS_HPP_

#include <string>

namespace com::bosch::itrams_gen2e {
namespace common {

class EventConstants {
public:
    static const std::string TEST_EVENT_TOPIC;    
    static const std::string TEST_COMMON_EVENT_TOPIC;  
    static const std::string TEST_TELEPHONY_EVENT_TOPIC;  
    static const std::string TEST_MODEMGR_EVENT_TOPIC;  
    // Add other constants as needed
};


}  // namespace common
}  // namespace com::bosch::itrams_gen2e

#endif /* COM_BOSCH_ITRAMS_EVENTCONSTANTS_H_ */
