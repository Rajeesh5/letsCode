#ifndef COM_BOSCH_COMMON_ITRAMS_EVENTADMIN_H_
#define COM_BOSCH_COMMON_ITRAMS_EVENTADMIN_H_

#include <map>
#include <mutex>
#include <vector>
#include <thread>
#include <queue>
#include <atomic>
#include <memory>

#include "data_types.hpp"
#include "event_handler.hpp"
#include "event.hpp"

#include "event_constants.hpp"

namespace com::bosch::itrams_gen2e {
namespace common {

class EventAdmin final{
 public:
    static std::shared_ptr<EventAdmin> getInstance() {
        // Use std::call_once for thread safety initialization
        std::call_once(initFlag_, [&]() {
             instance_.reset(new EventAdmin());
        });

        return instance_;
    }

    /**
     *  \brief Add a event to the dispatch queue
     *
     *  \param event A event that shall be handled
     *
     */
    void postEvent(std::shared_ptr<Event> event);

    /**
     * \brief Register a new handler that may receive events
     *
     * \param type The type of events that shall be dispatched to the handler
     * \param handler The handler instance
     *
     */

    void registerService(std::vector<std::string> topics,
                         std::shared_ptr<EventHandler> handler);

    ~EventAdmin() = default;

 private:
    EventAdmin();
    void processAsyncEvent();

    static std::shared_ptr<EventAdmin>         instance_;  
    static std::once_flag                      initFlag_;
    std::queue<std::shared_ptr<Event>>         async_event_q_;
    std::mutex                                 async_event_mutex_;
    std::atomic<bool>                          is_async_thread_active{false};
    std::map<std::string,
             std::vector<std::shared_ptr<EventHandler>>>        
                                               handlers_;
};

}  // namespace common
}  // namespace com::bosch::itrams_gen2e
#endif  // COM_BOSCH_COMMON_ITRAMS_EVENTADMIN_H_
