#ifndef COM_BOSCH_COMMON_ITRAMS_DATA_TYPES_H_
#define COM_BOSCH_COMMON_ITRAMS_DATA_TYPES_H_

#include <google/protobuf/message.h>
#include <google/protobuf/util/json_util.h>

#include <memory>
#include <string>
#include <cstdint>
#include <vector>
#include <utility>


namespace com::bosch::itrams_gen2e {
namespace common {


class PropertyKeys {
 public:
    static const std::string TEST_KEY;

};

class PluginName {
 public:
    static const std::string TEST_SHARED_PLUGIN;
};

}  // namespace common
}  // namespace com::bosch::itrams_gen2e

#endif  // COM_BOSCH_COMMON_ITRAMS_DATA_TYPES_H_
