#ifndef COM_BOSCH_COMMON_ITRAMS_EVENT_HPP_
#define COM_BOSCH_COMMON_ITRAMS_EVENT_HPP_

#include "event_constants.hpp"
#include "map"
#include "memory"
#include "vector"

namespace com::bosch::itrams_gen2e {
namespace common {

class Event {

public:    
    Event(const std::string& topic);
    Event(const std::string& topic, 
        const std::map<std::string, std::shared_ptr<void>>&&  properties);    

    template <typename T>
    void addProperty(const std::string& key, std::shared_ptr<T> value) {
        properties_[key] = std::static_pointer_cast<void>(value);
    }

    template <typename T>
    const T* getProperty(const std::string& key) const {
        auto it = properties_.find(key);
        if (it != properties_.end()) {
            auto castedPtr = std::static_pointer_cast<T>(it->second);
            return castedPtr.get();
        }
        return nullptr;
    }
    
    template<typename T>
    void addArrayProperty(const std::string& key, const T* value, size_t size) {
        properties_[key] = std::make_shared<std::vector<T>>(value, value + size);
    }

    template<typename T>
    const std::vector<T>* getArrayProperty(const std::string& key) const {
        auto it = properties_.find(key);
        if (it != properties_.end()) {
            return std::static_pointer_cast<std::vector<T>>(it->second).get();
        }
        return nullptr;
    }

    const std::string getTopic() const;
    std::vector<std::string> getPropertyNames() const;    
    bool containsProperty(const std::string& key) const;    
    
    std::size_t hash() const;
    
    const std::string toString() const;

    // No, Copy & move operation supported
    explicit Event(const Event& other) = delete;
    explicit Event(Event&& other) = delete;
    Event& operator=(const Event& other) = delete;
    Event& operator=(Event&& other) = delete;

private:
    void hash_combine(std::size_t& seed, std::size_t hash_value) const;
    void validateTopicName(const std::string& topic) const;
    std::string topic_;
    std::map<std::string, std::shared_ptr<void>> properties_;
};

}  // namespace common
}  // namespace com::bosch::itrams_gen2e

#endif  // COM_BOSCH_COMMON_ITRAMS_EVENT_HPP_