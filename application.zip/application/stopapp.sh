#!/bin/bash

# Find the process ID (PID) of the itrams_gen2e application
PID=$(pgrep -x itrams_gen2e)

# Check if the application is running
if [ -n "$PID" ]; then
    # Send SIGKILL signal to terminate the application
    kill -9 "$PID"
    
    # Check if the application was successfully terminated
    if [ $? -eq 0 ]; then
        echo "itrams_gen2e stopped successfully."
    else
        echo "Failed to stop itrams_gen2e."
    fi
else
    echo "itrams_gen2e is not running."
fi
